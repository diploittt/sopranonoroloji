import { PassportStrategy } from '@nestjs/passport';
import { Strategy, VerifyCallback, Profile } from 'passport-google-oauth20';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(private configService: ConfigService) {
    super({
      clientID:
        configService.get<string>('GOOGLE_CLIENT_ID') ||
        'GOOGLE_CLIENT_ID_NOT_SET',
      clientSecret:
        configService.get<string>('GOOGLE_CLIENT_SECRET') ||
        'GOOGLE_CLIENT_SECRET_NOT_SET',
      callbackURL:
        configService.get<string>('GOOGLE_CALLBACK_URL') ||
        'http://localhost:3001/auth/google/callback',
      scope: ['email', 'profile'],
    });
  }

  async validate(
    accessToken: string,
    refreshToken: string,
    profile: Profile,
    done: VerifyCallback,
  ): Promise<any> {
    const { name, emails, photos } = profile;
    const user = {
      email: emails?.[0]?.value,
      displayName:
        `${name?.givenName || ''} ${name?.familyName || ''}`.trim() ||
        profile.displayName,
      avatar: photos?.[0]?.value || null,
      provider: 'google',
      providerId: profile.id,
    };
    done(null, user);
  }
}
